function PlotResults1(targets, outputs, plotTitle)
    % Set up consistent styling parameters
    lineWidth = 1.5;
    targetColor = [0.2 0.4 0.8];  % Nice blue
    outputColor = [0.8 0.2 0.2];  % Nice red
    fitLineColor = [0.1 0.6 0.1]; % Green for fit line
    errorColor = [0.5 0.2 0.7];   % Purple for errors
    markerSize = 6;
    
    figure('Name', plotTitle, 'NumberTitle', 'off');
    
    % 1. Time series comparison
    subplot(2,2,1);
    plot(targets, 'Color', targetColor, 'LineWidth', lineWidth, 'DisplayName', 'Target');
    hold on;
    plot(outputs, ':', 'Color', outputColor, 'LineWidth', lineWidth, 'DisplayName', 'Output');
    title('Target vs Output');
    xlabel('Samples');
    ylabel('Value');
    legend('Location', 'best');
    grid on;
    
    % 2. Correlation plot
    subplot(2,2,2);
    scatter(targets, outputs, markerSize, 'filled', 'MarkerFaceColor', outputColor);
    hold on;
    xmin = min([targets, outputs]);
    xmax = max([targets, outputs]);
    plot([xmin xmax], [xmin xmax], '--', 'Color', fitLineColor, 'LineWidth', lineWidth);
    
    R = corr(targets', outputs');
    title(sprintf('Correlation (R = %.3f)', R));
    xlabel('Target');
    ylabel('Output');
    axis equal;
    grid on;
    
    % 3. Error plot
    subplot(2,2,3);
    errors = targets - outputs;
    plot(errors, 'Color', errorColor, 'LineWidth', lineWidth);
    title('Prediction Errors');
    xlabel('Samples');
    ylabel('Error');
    
    MSE = mean(errors.^2);
    RMSE = sqrt(MSE);
    text(0.05, 0.9, sprintf('MSE = %.2e\nRMSE = %.2e', MSE, RMSE), ...
        'Units', 'normalized', 'FontSize', 10);
    grid on;
    
    % 4. Error distribution
    subplot(2,2,4);
    h = histfit(errors, 50);
    h(1).FaceColor = [0.7 0.7 0.9];
    h(1).EdgeColor = 'none';
    h(2).Color = errorColor;
    h(2).LineWidth = lineWidth;
    
    eMean = mean(errors);
    eStd = std(errors);
    title(sprintf('Error Distribution (μ=%.2e, σ=%.2e)', eMean, eStd));
    xlabel('Error');
    ylabel('Count');
    grid on;
    
    % Improve overall figure appearance
    set(findall(gcf, 'Type', 'axes'), 'FontSize', 10, 'Box', 'off');
    set(gcf, 'Color', 'w');
    sgtitle(plotTitle, 'FontSize', 12, 'FontWeight', 'bold');
end