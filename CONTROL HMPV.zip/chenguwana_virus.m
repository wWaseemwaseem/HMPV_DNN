% Chikungunya Virus Model Simulation
% Parameters (example values - these should be adjusted based on actual data)
params.beta1 = 0.5;    % Transmission rate from mosquitoes to humans
params.beta2 = 0.5;    % Transmission rate from humans to mosquitoes
params.alpha = 1.0;    % Biting rate
params.mu_h = 1/(70*365);  % Human natural mortality rate (70 years lifespan)
params.mu_m = 1/14;        % Mosquito mortality rate (14 days lifespan)
params.nu_h = 1/3;         % Human incubation rate (3 days)
params.nu_m = 1/5;         % Mosquito incubation rate (5 days)
params.gamma_h = 1/7;      % Human recovery rate (7 days)
params.omega_h = 1/365;    % Human immunity loss rate (1 year)
params.Delta_h = 1000/365; % Human recruitment rate (1000 per year)
params.Delta_m = 5000/365; % Mosquito recruitment rate (5000 per year)

% Initial conditions
% [S_h, epsilon_h, I_h, R_h, S_m, epsilon_m, I_m]
initial_conditions = [
    10000;   % S_h: Susceptible humans
    10;      % epsilon_h: Exposed humans  
    5;       % I_h: Infected humans
    100;     % R_h: Recovered humans
    50000;   % S_m: Susceptible mosquitoes
    100;     % epsilon_m: Exposed mosquitoes
    50       % I_m: Infected mosquitoes
];

% Time span for simulation (in days)
tspan = [0 365];  % One year simulation

% Solve the system using ode45
[t, y] = ode45(@(t,y) chikungunya_ode(t, y, params), tspan, initial_conditions);

% Extract solution components
S_h = y(:,1);
epsilon_h = y(:,2);
I_h = y(:,3);
R_h = y(:,4);
S_m = y(:,5);
epsilon_m = y(:,6);
I_m = y(:,7);

% Calculate total human and mosquito populations
N_h = S_h + epsilon_h + I_h + R_h;
N_m = S_m + epsilon_m + I_m;

% Plot Human Dynamics
figure('Position', [100, 100, 1200, 800]);

subplot(2,3,1);
plot(t, S_h, 'b-', 'LineWidth', 2);
xlabel('Time (days)');
ylabel('Population');
title('Susceptible Humans (S_h)');
grid on;

subplot(2,3,2);
plot(t, epsilon_h, 'm-', 'LineWidth', 2);
xlabel('Time (days)');
ylabel('Population');
title('Exposed Humans (\epsilon_h)');
grid on;

subplot(2,3,3);
plot(t, I_h, 'r-', 'LineWidth', 2);
xlabel('Time (days)');
ylabel('Population');
title('Infected Humans (I_h)');
grid on;

subplot(2,3,4);
plot(t, R_h, 'g-', 'LineWidth', 2);
xlabel('Time (days)');
ylabel('Population');
title('Recovered Humans (R_h)');
grid on;

subplot(2,3,5);
plot(t, N_h, 'k-', 'LineWidth', 2);
xlabel('Time (days)');
ylabel('Population');
title('Total Human Population (N_h)');
grid on;

% Plot Mosquito Dynamics
figure('Position', [100, 100, 1200, 400]);

subplot(1,3,1);
plot(t, S_m, 'b-', 'LineWidth', 2);
xlabel('Time (days)');
ylabel('Population');
title('Susceptible Mosquitoes (S_m)');
grid on;

subplot(1,3,2);
plot(t, epsilon_m, 'm-', 'LineWidth', 2);
xlabel('Time (days)');
ylabel('Population');
title('Exposed Mosquitoes (\epsilon_m)');
grid on;

subplot(1,3,3);
plot(t, I_m, 'r-', 'LineWidth', 2);
xlabel('Time (days)');
ylabel('Population');
title('Infected Mosquitoes (I_m)');
grid on;

% Combined plot
figure('Position', [100, 100, 1400, 600]);

subplot(1,2,1);
plot(t, S_h, 'b-', t, epsilon_h, 'm-', t, I_h, 'r-', t, R_h, 'g-', 'LineWidth', 1.5);
xlabel('Time (days)');
ylabel('Population');
title('Human Compartment Dynamics');
legend('S_h', '\epsilon_h', 'I_h', 'R_h', 'Location', 'best');
grid on;

subplot(1,2,2);
plot(t, S_m, 'b-', t, epsilon_m, 'm-', t, I_m, 'r-', 'LineWidth', 1.5);
xlabel('Time (days)');
ylabel('Population');
title('Mosquito Compartment Dynamics');
legend('S_m', '\epsilon_m', 'I_m', 'Location', 'best');
grid on;

% Save parameters for reference
disp('Model Parameters:');
disp(params);
disp(' ');
disp('Initial Conditions:');
disp(['S_h(0) = ' num2str(initial_conditions(1))]);
disp(['epsilon_h(0) = ' num2str(initial_conditions(2))]);
disp(['I_h(0) = ' num2str(initial_conditions(3))]);
disp(['R_h(0) = ' num2str(initial_conditions(4))]);
disp(['S_m(0) = ' num2str(initial_conditions(5))]);
disp(['epsilon_m(0) = ' num2str(initial_conditions(6))]);
disp(['I_m(0) = ' num2str(initial_conditions(7))]);

% ODE function definition
function dydt = chikungunya_ode(t, y, p)
    % Extract variables
    S_h = y(1);
    epsilon_h = y(2);
    I_h = y(3);
    R_h = y(4);
    S_m = y(5);
    epsilon_m = y(6);
    I_m = y(7);
    
    % Calculate total human population
    N_h = S_h + epsilon_h + I_h + R_h;
    
    % Human equations
    dS_h = p.Delta_h - (p.beta1 * p.alpha / N_h) * S_h * I_m - p.mu_h * S_h + p.omega_h * R_h;
    depsilon_h = (p.beta1 * p.alpha / N_h) * S_h * I_m - (p.nu_h + p.mu_h) * epsilon_h;
    dI_h = p.nu_h * epsilon_h - (p.gamma_h + p.mu_h) * I_h;
    dR_h = p.gamma_h * I_h - (p.mu_h + p.omega_h) * R_h;
    
    % Mosquito equations
    dS_m = p.Delta_m - (p.beta2 * p.alpha / N_h) * S_m * I_h - p.mu_m * S_m + p.mu_m * I_m;
    depsilon_m = (p.beta2 * p.alpha / N_h) * S_m * I_h - (p.nu_m + p.mu_m) * epsilon_m;
    dI_m = p.nu_m * epsilon_m - p.mu_m * I_m;
    
    % Return derivatives
    dydt = [dS_h; depsilon_h; dI_h; dR_h; dS_m; depsilon_m; dI_m];
end