% ============================================================
% Fractional-order optimal control solver (forward-backward sweep)
% Model: your 9-compartment system with controls c1..c5
% Fractional derivative: Caputo, implemented via GL weights
% ============================================================

clear; clc;

% ----------------------------
% 1) Time grid and fractional order
% ----------------------------
tf = 200;          % final time
N  = 2000;         % number of steps
t  = linspace(0, tf, N+1);
h  = t(2) - t(1);

q  = 0.95;         % fractional order in (0,1]

% GL weights for Caputo-like implementation (memory weights)
w = zeros(N+1,1);
w(1) = 1;
for k = 2:N+1
    w(k) = (1 - (1+q)/(k-1)) * w(k-1);  % w_k = (1-(1+q)/(k-1))*w_{k-1}
end
hq = h^q;

% ----------------------------
% 2) Parameters (fill with your values)
% ----------------------------
par.Pi   = 1;     % \Pi
par.tau  = 0.2;   % \tau
par.pi   = 0.1;   % \pi
par.d    = 0.01;  % d

par.eta1 = 0.3; par.eta2 = 0.3;
par.a1   = 0.2; par.a2   = 0.1;

par.th1  = 0.4; par.th2  = 0.4;
par.th3  = 0.3; par.th4  = 0.3;

par.d1=0.01; par.d2=0.01; par.d3=0.01; par.d4=0.01; par.d5=0.01;

par.gamma = 0.2; par.kappa = 0.05;  % \gamma, \kappa
par.theta = 0.2;                    % \theta (in T equation)

par.sig1 = 0.2; par.sig2 = 0.2;
% NOTE: your B eq has (sig1*lambdaH + sig2*lambdaH); keep as shown.

% ----------------------------
% 3) Cost weights (edit to match your paper)
% ----------------------------
W.H   = 1;  W.A   = 1;  W.B   = 1;
W.CHB = 1;  W.CAB = 1;

R.c1 = 50; R.c2 = 50; R.c3 = 50; R.c4 = 50; R.c5 = 50;

% If your incidence into B uses (1-c2)*lambdaB*S, set this true:
use_c2_in_B_gain = true;

% ----------------------------
% 4) Initial conditions (edit)
% ----------------------------
x0 = zeros(9,1);
% State order: [S P H A B CHB CAB T TB]'
x0(1)=1000; x0(2)=50; x0(3)=10; x0(4)=5; x0(5)=8;
x0(6)=1; x0(7)=1; x0(8)=0; x0(9)=0;

% ----------------------------
% 5) Initialize controls
% ----------------------------
c1 = 0.2*ones(N+1,1);
c2 = 0.2*ones(N+1,1);
c3 = 0.2*ones(N+1,1);
c4 = 0.2*ones(N+1,1);
c5 = 0.2*ones(N+1,1);

% ----------------------------
% 6) Iteration settings
% ----------------------------
maxIter = 200;
tol     = 1e-6;
relax   = 0.6;   % relaxation to stabilize iterations

% Storage
X = zeros(9, N+1);
P = zeros(9, N+1);

% ============================================================
% Main forward-backward sweep
% ============================================================
for it = 1:maxIter

    c1_old=c1; c2_old=c2; c3_old=c3; c4_old=c4; c5_old=c5;

    % -------- Forward solve (fractional states) --------
    X(:,1) = x0;

    for n = 1:N
        xn = X(:,1:n); % history up to n

        % compute f at time index n+1 using explicit predictor:
        % Use last state as predictor (simple). You can upgrade to implicit.
        x_pred = X(:,n);

        % Evaluate lambdas at predictor
        lamH = lambdaH_fun(x_pred, par);
        lamB = lambdaB_fun(x_pred, par);

        f_pred = f_state(x_pred, c1(n),c2(n),c3(n),c4(n),c5(n), lamH, lamB, par, use_c2_in_B_gain);

        % GL update:
        % x_{n+1} = h^q f(x_pred) - sum_{k=1}^{n+1} w(k+1) x_{n+1-k}  (rearranged)
        mem = zeros(9,1);
        for k = 1:n
            mem = mem + w(k+1) * X(:,n+1-k);
        end
        % w(1)=1 corresponds to x_{n+1} term; rearrange:
        X(:,n+1) = hq * f_pred - mem;
        % (This is a commonly used explicit GL form; keep h small for stability.)

        % enforce nonnegativity if desired
        X(:,n+1) = max(X(:,n+1), 0);
    end

    % -------- Backward solve (adjoints) --------
    % Terminal conditions (for free terminal state): p(tf)=0
    P(:,N+1) = 0;

    % Backward in time with a “time-reversal” trick:
    % Define s = tf - t, and integrate forward in s for the adjoint.
    % Implemented here by stepping backward with the same GL memory form.

    for n = N:-1:1
        % Use current state at time n for gradients
        x = X(:,n);

        lamH = lambdaH_fun(x, par);
        lamB = lambdaB_fun(x, par);

        % Running cost gradients dL/dx
        dLdx = zeros(9,1);
        dLdx(3) = W.H;      % H
        dLdx(4) = W.A;      % A
        dLdx(5) = W.B;      % B
        dLdx(6) = W.CHB;    % CHB
        dLdx(7) = W.CAB;    % CAB

        % Compute -dH/dx = dL/dx + sum p_i * df_i/dx with sign
        % We implement adjoint RHS: g = dL/dx + (df/dx)' * p
        % then use a backward GL step.
        p_next = P(:,n+1);
        g = adjoint_rhs(x, p_next, c1(n),c2(n),c3(n),c4(n),c5(n), lamH, lamB, par, dLdx, use_c2_in_B_gain);

        % Backward GL step for adjoint:
        % p_n = h^q g - sum_{k=1}^{N-n+1} w(k+1) p_{n+k-1}
        mem = zeros(9,1);
        kkMax = (N - n + 1);
        for k = 1:kkMax
            mem = mem + w(k+1) * P(:, n+k);
        end
        P(:,n) = hq * g - mem;
    end

    % -------- Control update via projection --------
    for n = 1:N+1
        x = X(:,n);
        p = P(:,n);

        S  = x(1); H  = x(3); A  = x(4); B  = x(5);
        CHB= x(6); CAB= x(7);

        pS   = p(1); pH=p(3); pA=p(4); pB=p(5);
        pCHB = p(6); pCAB=p(7); pT=p(8); pTB=p(9);

        lamH = lambdaH_fun(x, par);
        lamB = lambdaB_fun(x, par);

        % c1*
        u1 = (lamH*S*(pH - pS))/R.c1;

        % c2* (choose consistent incidence form)
        if use_c2_in_B_gain
            u2 = (lamB*S*(pB - pS))/R.c2;
        else
            % If c2 only appears in S equation (as in screenshot), a common update is:
            u2 = (lamB*S*(0 - pS))/R.c2; % tends to project to 0 in many cases
        end

        % c3*
        u3 = (par.th1*H*(pH - pT) + par.th2*A*(pA - pT))/R.c3;

        % c4*
        u4 = (par.gamma*B*(pB - pTB))/R.c4;

        % c5*
        u5 = (par.th3*CHB*(pCHB - pT) + par.th4*CAB*(pCAB - pT))/R.c5;

        % projection to [0,1]
        c1(n) = min(1, max(0, u1));
        c2(n) = min(1, max(0, u2));
        c3(n) = min(1, max(0, u3));
        c4(n) = min(1, max(0, u4));
        c5(n) = min(1, max(0, u5));
    end

    % relaxation (helps convergence)
    c1 = relax*c1 + (1-relax)*c1_old;
    c2 = relax*c2 + (1-relax)*c2_old;
    c3 = relax*c3 + (1-relax)*c3_old;
    c4 = relax*c4 + (1-relax)*c4_old;
    c5 = relax*c5 + (1-relax)*c5_old;

    % convergence check
    err = max([ norm(c1-c1_old,inf), norm(c2-c2_old,inf), norm(c3-c3_old,inf), ...
                norm(c4-c4_old,inf), norm(c5-c5_old,inf) ]);

    fprintf('Iter %d, control change = %.3e\n', it, err);

    if err < tol
        break;
    end
end

% Plot example
figure; plot(t, X(3,:), 'LineWidth', 1.5); xlabel('t'); ylabel('H(t)');
figure; plot(t, c1, 'LineWidth', 1.5); xlabel('t'); ylabel('c_1(t)');


% ============================================================
% ----- Model-specific functions -----
% ============================================================

function lamH = lambdaH_fun(x, par)
    % >>> Replace with your actual force of infection lambda_H
    % Example (mass-action): betaH * (H+A+B+CHB+CAB)/N
    betaH = 1e-4;
    S=x(1); P=x(2); H=x(3); A=x(4); B=x(5); CHB=x(6); CAB=x(7); T=x(8); TB=x(9);
    N = S+P+H+A+B+CHB+CAB+T+TB + 1e-12;
    lamH = betaH * (H + A + B + CHB + CAB) / N;
end

function lamB = lambdaB_fun(x, par)
    % >>> Replace with your actual force of infection lambda_B
    betaB = 1e-4;
    S=x(1); P=x(2); H=x(3); A=x(4); B=x(5); CHB=x(6); CAB=x(7); T=x(8); TB=x(9);
    N = S+P+H+A+B+CHB+CAB+T+TB + 1e-12;
    lamB = betaB * (B + CHB + CAB) / N;
end

function f = f_state(x, c1,c2,c3,c4,c5, lamH, lamB, par, use_c2_in_B_gain)
    % State vector: [S P H A B CHB CAB T TB]'
    S=x(1); P=x(2); H=x(3); A=x(4); B=x(5); CHB=x(6); CAB=x(7); T=x(8); TB=x(9);

    f = zeros(9,1);

    f(1) = (1-par.tau)*par.Pi + par.pi*P ...
           - ((1-c1)*lamH + (1-c2)*lamB + par.d)*S;

    f(2) = par.tau*par.Pi - (par.pi + par.d)*P;

    f(3) = (1-c1)*lamH*S ...
           - (par.eta1*lamB + par.a1 + c3*par.th1 + par.d2 + par.d)*H;

    f(4) = par.a1*H ...
           - (par.eta2*lamB + c3*par.th2 + par.d3 + par.d)*A;

    if use_c2_in_B_gain
        incB = (1-c2)*lamB*S;
    else
        incB = lamB*S; % as in screenshot
    end

    f(5) = incB + par.kappa*TB ...
           - ((par.sig1+par.sig2)*lamH + c4*par.gamma + par.d1 + par.d)*B;

    f(6) = par.eta1*lamB*H + par.sig1*lamH*B ...
           - (par.a2 + c5*par.th3 + par.d4 + par.d)*CHB;

    f(7) = par.a2*CHB ...
           - (par.eta2*lamB*A + par.sig2*lamH*B + c5*par.th4 + par.d5 + par.d)*CAB;

    f(8) = c3*par.th1*H + c3*par.th2*A + c5*par.th3*CHB + c5*par.th4*CAB ...
           - (par.theta + par.d)*T;

    f(9) = c4*par.gamma*B - (par.kappa + par.d)*TB;
end

function g = adjoint_rhs(x, p, c1,c2,c3,c4,c5, lamH, lamB, par, dLdx, use_c2_in_B_gain)
    % g = dL/dx + (df/dx)' * p
    % This requires partial derivatives. For readability, we implement
    % the dominant terms from your equations. If your lambdas depend on x,
    % their derivatives should be added (often omitted in first implementation).

    S=x(1); Pp=x(2); H=x(3); A=x(4); B=x(5); CHB=x(6); CAB=x(7); T=x(8); TB=x(9);

    g = dLdx;

    % For simplicity, treat lamH and lamB as exogenous (no dlam/dx terms).
    % Then compute df/dx contributions.

    % Build Jacobian J = df/dx (9x9) under this approximation
    J = zeros(9,9);

    % f1 = ... -((1-c1)lamH+(1-c2)lamB + d) S
    J(1,1) = -((1-c1)*lamH + (1-c2)*lamB + par.d);
    J(1,2) = par.pi;

    % f2 = tau Pi - (pi+d) P
    J(2,2) = -(par.pi + par.d);

    % f3 = (1-c1)lamH S - (...) H
    J(3,1) = (1-c1)*lamH;
    J(3,3) = -(par.eta1*lamB + par.a1 + c3*par.th1 + par.d2 + par.d);

    % f4 = a1 H - (...) A
    J(4,3) = par.a1;
    J(4,4) = -(par.eta2*lamB + c3*par.th2 + par.d3 + par.d);

    % f5
    if use_c2_in_B_gain
        J(5,1) = (1-c2)*lamB;
    else
        J(5,1) = lamB;
    end
    J(5,5) = -((par.sig1+par.sig2)*lamH + c4*par.gamma + par.d1 + par.d);
    J(5,9) = par.kappa;

    % f6
    J(6,3) = par.eta1*lamB;
    J(6,5) = par.sig1*lamH;
    J(6,6) = -(par.a2 + c5*par.th3 + par.d4 + par.d);

    % f7
    J(7,6) = par.a2;
    J(7,4) = -(par.eta2*lamB);
    J(7,5) = -(par.sig2*lamH);
    J(7,7) = -(c5*par.th4 + par.d5 + par.d);

    % f8
    J(8,3) = c3*par.th1;
    J(8,4) = c3*par.th2;
    J(8,6) = c5*par.th3;
    J(8,7) = c5*par.th4;
    J(8,8) = -(par.theta + par.d);

    % f9
    J(9,5) = c4*par.gamma;
    J(9,9) = -(par.kappa + par.d);

    % g = dLdx + J' * p
    g = g + J' * p;
end
