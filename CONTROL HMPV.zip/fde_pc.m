function X = fde_pc(q, fhandle, t0, T, X0, h, params)
% fde_pc  Predictor-Corrector Adams–Bashforth–Moulton method
%         for Caputo fractional derivative of order 0 < q <= 1.
%
% {}^C D_t^q X(t) = f(t, X(t)),  X(t0) = X0
%
% INPUTS:
%   q       - fractional order (0 < q <= 1)
%   fhandle - function handle f(t, X, params)
%   t0, T   - initial and final time
%   X0      - initial condition column vector (dimension: d x 1)
%   h       - time step
%   params  - parameters passed to f
%
% OUTPUT:
%   X       - matrix of size (N x d), solution at each grid point

if q <= 0 || q > 1
    error('Order q must satisfy 0 < q <= 1.');
end

% Time grid
t = t0:h:T;
N = length(t);
d = length(X0);

X = zeros(N, d);
X(1, :) = X0(:).';

% Gamma function factor
gq = 1 / gamma(q);

% Precompute coefficients for the predictor–corrector
% We use weights a_{j,k} and b_{j,k} as in Diethelm et al.
% For efficiency, precompute constants once.
fprintf('Precomputing fractional weights...\n');

% Coefficients for the corrector (A coefficients)
A = zeros(N, N);
for n = 2:N
    for j = 1:n
        if j == 1
            A(n,j) = (n-1)^(q) - (n-1 - q)*(n-2)^(q);
        elseif j == n
            A(n,j) = 1;
        else
            A(n,j) = (n-j+1)^(q) - 2*(n-j)^(q) + (n-j-1)^(q);
        end
    end
end
A = A * (h^q * gq);

% Coefficients for predictor (B coefficients)
B = zeros(N, N);
for n = 2:N
    for j = 1:n-1
        B(n,j) = ( (n - j + 1)^(q) - (n - j)^(q) );
    end
end
B = B * (h^q * gq);

% Main time-stepping
fprintf('Running predictor–corrector loop (N = %d)...\n', N);

for n = 2:N
    tn   = t(n);
    % Predictor step: explicit approximation
    % X^P_n = X0 + 1/Gamma(q) * sum_{j=1}^{n-1} ( (t_n - t_j)^{q-1} ) f(t_j, X_j) * h
    % We use precomputed B(n,j) for the convolution weights.

    % Sum for predictor
    sum_pred = zeros(d,1);
    for j = 1:n-1
        fj = fhandle(t(j), X(j,:).', params);
        sum_pred = sum_pred + B(n,j) * fj;
    end

    X_pred = X0(:) + sum_pred;  % predictor

    % Corrector step: implicit
    % X_n = X0 + 1/Gamma(q) * [ sum_{j=1}^{n-1} a_{n,j} f(t_j, X_j) + a_{n,n} f(t_n, X_pred) ]
    sum_corr = zeros(d,1);
    for j = 1:n-1
        fj = fhandle(t(j), X(j,:).', params);
        sum_corr = sum_corr + A(n,j) * fj;
    end
    fn_pred = fhandle(tn, X_pred, params);
    sum_corr = sum_corr + A(n,n) * fn_pred;

    X(n,:) = (X0(:) + sum_corr).';
end
end
