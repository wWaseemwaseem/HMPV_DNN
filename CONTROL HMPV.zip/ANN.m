%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%   Exercise for the selection of candidates for the call     %%%
%%%      慥AC-2021-42 - PhD Position in CIMNE MARINE�            %%%
%%%                                                             %%%
%%%                   Mohammad Sadegh Eshaghi                   %%%
%%%                                                             %%%
%%%  The code to identify the optimal architecture of the MLP   %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% clc;
% clear;
% close all;

%% Loading Database

load('alldataHMPV.mat') % The database is achieved from the code for solving ODE
% Data = [Ia;Ia1;Ia2;Ia3;Ia4;Ia5];

%% Remving the data related to unstable states

%Data(Data(:,5)>50,:)=[];

%% Training Neural Network

inputs = t;
targets = [xout;x];

% Display the size of arrays to understand the structure
disp(['Size of xout: ', num2str(size(xout))]);
disp(['Size of x: ', num2str(size(x))]);
disp(['Size of targets: ', num2str(size(targets))]);
% disp(['Size of outputs: ', num2str(size(outputs))]);


% Create a Fitting Network

%hiddenLayerSize = 20;          % one-hidden-layer ANNs (2-20-1-MLP)
%hiddenLayerSize = [5 15];      % two-hidden-layer ANNs (2-5-15-1-MLP)
hiddenLayerSize = [10 15];       % two-hidden-layer ANNs (2-15-5-1-MLP)

TF={'tansig','purelin'};
net = newff(inputs,targets,hiddenLayerSize,TF);

% Choose Input and Output Pre/Post-Processing Functions
% For a list of all processing functions type: help nnprocess
net.inputs{1}.processFcns = {'removeconstantrows','mapminmax'};
net.outputs{2}.processFcns = {'removeconstantrows','mapminmax'};

% Setup Division of Data for Training, Validation, Testing
% For a list of all data division functions type: help nndivide
net.divideFcn = 'dividerand';  % Divide data randomly
net.divideMode = 'sample';  % Divide up every sample
net.divideParam.trainRatio = 70/100;
net.divideParam.valRatio = 15/100;
net.divideParam.testRatio = 15/100;

% For help on training function 'trainlm' type: help trainlm
% For a list of all training functions type: help nntrain
net.trainFcn = 'trainlm';  % Levenberg-Marquardt

% Choose a Performance Function
% For a list of all performance functions type: help nnperformance
net.performFcn = 'mse';  % Mean squared error

% Choose Plot Functions
% For a list of all plot functions type: help nnplot
net.plotFcns = {'plotperform','ploterrhist','plotregression','plotfit'};

net.trainParam.showWindow=true;
net.trainParam.showCommandLine=false;
net.performParam.normalization='standard';
net.trainParam.show=1;
% net.trainParam.epochs=1000;
% net.trainParam.goal=1e-20;
% net.trainParam.max_fail=20;


% Train the Network
[net,tr] = train(net,inputs,targets);

% Test the Network
outputs = net(inputs);
errors = gsubtract(targets,outputs);
performance = perform(net,targets,outputs);

% Recalculate Training, Validation and Test Performance
trainInd=tr.trainInd;
trainInputs = inputs(:,trainInd);
trainTargets = targets(:,trainInd);
trainOutputs = outputs(:,trainInd);
trainErrors = trainTargets-trainOutputs;
trainPerformance = perform(net,trainTargets,trainOutputs);

valInd=tr.valInd;
valInputs = inputs(:,valInd);
valTargets = targets(:,valInd);
valOutputs = outputs(:,valInd);
valErrors = valTargets-valOutputs;
valPerformance = perform(net,valTargets,valOutputs);

testInd=tr.testInd;
testInputs = inputs(:,testInd);
testTargets = targets(:,testInd);
testOutputs = outputs(:,testInd);
testError = testTargets-testOutputs;
testPerformance = perform(net,testTargets,testOutputs);

%% Results for Target
% PlotResults1(targets(1,:),outputs(1,:),'All Data (1)');
% print('-depsc2', 'Alldataplot1.eps');
% PlotResults1(trainTargets(1,:),trainOutputs(1,:),'Train Data (1)');
% print('-depsc2', 'traindataplot1.eps');
% PlotResults1(valTargets(1,:),valOutputs(1,:),'Validation Data (1)');
% print('-depsc2', 'validationdataplot1.eps');
% PlotResults1(testTargets(1,:),testOutputs(1,:),'Test Data (1)');
% print('-depsc2', 'testdataplot1.eps');

%%
figure
plot(t,outputs(1,:),':','linewidth',2)
hold on
plot(t,xout(1,:),'ok','linewidth',1,'MarkerIndices',[1:5:100])
plot(t,outputs(8,:),':','linewidth',2) % Changed from 6 to 8
plot(t,x(1,:),'ok','linewidth',1,'MarkerIndices',[1:5:100])
hold off
xlabel('time(days)')
ylabel('S(t)')
grid on
set(gca, 'FontWeight','b','FontSize',12,'yscale','linear')
legend('S(Predicted DNN Without control)','S(Numerical RK-4 Without control)','S(Predicted DNN With control)','S(Numerical RK-4 With control) ')
print('-depsc2', 'optimalplot1.eps');

%%
figure
plot(t,outputs(2,:),':','linewidth',2)
hold on
plot(t,xout(2,:),'ok','linewidth',1,'MarkerIndices',[1:5:100])
plot(t,outputs(9,:),':','linewidth',2) % Changed from 7 to 9
plot(t,x(2,:),'ok','linewidth',1,'MarkerIndices',[1:5:100])
hold off
xlabel('time(days)')
ylabel('E(t)')
grid on
set(gca, 'FontWeight','b','FontSize',12,'yscale','linear')
legend('E(Predicted DNN Without control)','E(Numerical RK-4 Without control)','E(Predicted DNN With control)','E(Numerical RK-4 With control) ')
print('-depsc2', 'optimalplot2.eps');

%%
figure
plot(t,outputs(3,:),':','linewidth',2)
hold on
plot(t,xout(3,:),'ok','linewidth',1,'MarkerIndices',[1:5:100])
plot(t,outputs(10,:),':','linewidth',2) % Changed from 8 to 10
plot(t,x(3,:),'ok','linewidth',1,'MarkerIndices',[1:5:100])
hold off
xlabel('time(days)')
ylabel('A(t)')
grid on
set(gca, 'FontWeight','b','FontSize',12,'yscale','linear')
legend('A(Predicted DNN Without control)','A(Numerical RK-4 Without control)','A(Predicted DNN With control)','A(Numerical RK-4 With control) ')
print('-depsc2', 'optimalplot3.eps');

%%
figure
plot(t,outputs(4,:),':','linewidth',2)
hold on
plot(t,xout(4,:),'ok','linewidth',1,'MarkerIndices',[1:5:100])
plot(t,outputs(11,:),':','linewidth',2) % Changed from 9 to 11
plot(t,x(4,:),'ok','linewidth',1,'MarkerIndices',[1:5:100])
hold off
xlabel('time(days)')
ylabel('I(t)')
grid on
set(gca, 'FontWeight','b','FontSize',12,'yscale','linear')
legend('I(Predicted DNN Without control)','I(Numerical RK-4 Without control)','I(Predicted DNN With control)','I(Numerical RK-4 With control) ')
print('-depsc2', 'optimalplot4.eps');

%%
figure
plot(t,outputs(5,:),':','linewidth',2)
hold on
plot(t,xout(5,:),'ok','linewidth',1,'MarkerIndices',[1:5:100])
plot(t,outputs(12,:),':','linewidth',2) % Changed from 10 to 12
plot(t,x(5,:),'ok','linewidth',1,'MarkerIndices',[1:5:100])
hold off
xlabel('time(days)')
ylabel('H(t)')
grid on
set(gca, 'FontWeight','b','FontSize',12,'yscale','linear')
legend('H(Predicted DNN Without control)','H(Numerical RK-4 Without control)','H(Predicted DNN With control)','H(Numerical RK-4 With control) ')
print('-depsc2', 'optimalplot5.eps');

%% NEW: Plot for C variable (6th variable)
figure
plot(t,outputs(6,:),':','linewidth',2)
hold on
plot(t,xout(6,:),'ok','linewidth',1,'MarkerIndices',[1:5:100])
plot(t,outputs(13,:),':','linewidth',2) % Changed from 16 to 13
plot(t,x(6,:),'ok','linewidth',1,'MarkerIndices',[1:5:100])
hold off
xlabel('time(days)')
ylabel('C(t)')
grid on
set(gca, 'FontWeight','b','FontSize',12,'yscale','linear')
legend('C(Predicted DNN Without control)','C(Numerical RK-4 Without control)','C(Predicted DNN With control)','C(Numerical RK-4 With control) ')
print('-depsc2', 'optimalplot6.eps');

%% NEW: Plot for R variable (7th variable)
figure
plot(t,outputs(7,:),':','linewidth',2)
hold on
plot(t,xout(7,:),'ok','linewidth',1,'MarkerIndices',[1:5:100])
plot(t,outputs(14,:),':','linewidth',2) % Changed from 17 to 14
plot(t,x(7,:),'ok','linewidth',1,'MarkerIndices',[1:5:100])
hold off
xlabel('time(days)')
ylabel('R(t)')
grid on
set(gca, 'FontWeight','b','FontSize',12,'yscale','linear')
legend('R(Predicted DNN Without control)','R(Numerical RK-4 Without control)','R(Predicted DNN With control)','R(Numerical RK-4 With control) ')
print('-depsc2', 'optimalplot7.eps');

%% Calculating Statistic Index
figure('Name','Fig2: Variation of \beta','NumberTitle','off')
semilogy(t,abs(errors(1,:)),'-.','linewidth',1.5)
hold on
semilogy(t,abs(errors(2,:)),'-.','linewidth',1.5)
semilogy(t,abs(errors(3,:)),'-.','linewidth',1.5)
semilogy(t,abs(errors(4,:)),'-.','linewidth',1.5)
semilogy(t,abs(errors(5,:)),'-.','linewidth',1.5)
semilogy(t,abs(errors(6,:)),'-.','linewidth',1.5)  
semilogy(t,abs(errors(7,:)),'-.','linewidth',1.5)  
hold off
xlabel('t')
ylabel('Absolute errors')
grid on
set(gca, 'FontWeight','b','FontSize',12,'yscale','log')
legend('S','E','A','I','H','C','R')
print('-depsc2', 'AEplot.eps');

Param = CalculateStatistic(targets,outputs)