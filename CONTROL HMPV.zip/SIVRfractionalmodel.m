%% main_fractional_SIVR_DNN.m
% Fractional SIVR model (Caputo derivative) + DNN approximation
clear; clc; close all;

%% ================== Parameters ==================
% Fractional order (0 < q <= 1)
q  = 0.9;

% Time settings
Tend = 150;          % final time
h    = 0.05;         % time step
t    = 0:h:Tend;     % time grid
Nt   = length(t);

% Epidemiological parameters (example values – adjust)
Lambda = 10;   % recruitment
p      = 0.3;  % fraction of vaccinated at recruitment
beta   = 0.7;  % transmission rate
alpha  = 0.1;  % incidence saturation
gamma  = 0.4;  % recovery coefficient
mu     = 0.5;  % treatment effort
b      = 0.1;  % treatment saturation
m      = 0.2;  % vaccination from infected
delta  = 0.01; % disease-induced death
d      = 0.02; % natural death
qv     = 0.1;  % waning of vaccine (S <- V)
kappa  = 0.15; % recovery from V

params = [Lambda, p, beta, alpha, gamma, mu, b, m, delta, d, qv, kappa];

%% ================== Initial conditions ==================
S0 = 800;
I0 = 10;
V0 = 100;
R0 = 0;

X0 = [S0; I0; V0; R0];

%% ================== Fractional Solver ==================
% Solve {}^C D_t^q X = f(t, X)
% Using predictor–corrector Adams–Bashforth–Moulton (Diethelm type)
fprintf('Solving fractional SIVR system (q = %.2f)...\n', q);

% X will be Nt x 4 matrix (each column: S, I, V, R)
X = fde_pc(q, rhs_SIVR, 0, Tend, X0, h, params);

S = X(:,1);
I = X(:,2);
V = X(:,3);
R = X(:,4);

%% ================== Plot reference solution ==================
figure;
plot(t, S, 'LineWidth', 1.5); hold on;
plot(t, I, 'LineWidth', 1.5);
plot(t, V, 'LineWidth', 1.5);
plot(t, R, 'LineWidth', 1.5);
xlabel('t');
ylabel('Population');
legend('S(t)','I(t)','V(t)','R(t)','Location','best');
title(sprintf('Fractional SIVR solution (q = %.2f)', q));
grid on;

%% ================== Prepare data for DNN ==================
% Input: time t (1 x Nt)
% Output: states [S; I; V; R] (4 x Nt)
input  = t;                 % 1 x Nt
target = [S.'; I.'; V.'; R.'];  % 4 x Nt

% Optional normalization (MATLAB nn toolbox will usually handle internally)
% [inputN, inputSettings]   = mapminmax(input);
% [targetN, targetSettings] = mapminmax(target);

%% ================== Define and train DNN ==================
% Use FITNET (regression network) or FEEDFORWARDNET
hiddenLayerSize = [50 5];      % two hidden layers: 50 and 5 neurons
net = fitnet(hiddenLayerSize);

% Choose activation functions (transfer functions)
net.layers{1}.transferFcn = 'tansig';  % first hidden
net.layers{2}.transferFcn = 'poslin';  % second hidden (ReLU-like)

% Data division: 70% train, 15% val, 15% test (default)
net.divideParam.trainRatio = 0.7;
net.divideParam.valRatio   = 0.15;
net.divideParam.testRatio  = 0.15;

% Training function (Levenberg–Marquardt)
net.trainFcn = 'trainlm';

% Train
fprintf('Training DNN surrogate...\n');
[net, tr] = train(net, input, target);

% DNN predictions on the same grid
Yhat = net(input);   % 4 x Nt
S_hat = Yhat(1,:).';
I_hat = Yhat(2,:).';
V_hat = Yhat(3,:).';
R_hat = Yhat(4,:).';

%% ================== Error analysis ==================
% Pointwise absolute errors
AE_S = abs(S - S_hat);
AE_I = abs(I - I_hat);
AE_V = abs(V - V_hat);
AE_R = abs(R - R_hat);

% MSE, RMSE, R^2 (simple versions)
MSE_S  = mean((S - S_hat).^2);
MSE_I  = mean((I - I_hat).^2);
MSE_V  = mean((V - V_hat).^2);
MSE_R  = mean((R - R_hat).^2);

RMSE_S = sqrt(MSE_S);
RMSE_I = sqrt(MSE_I);
RMSE_V = sqrt(MSE_V);
RMSE_R = sqrt(MSE_R);

% Compute R^2 for each compartment
R2_S = 1 - sum((S - S_hat).^2) / sum((S - mean(S)).^2);
R2_I = 1 - sum((I - I_hat).^2) / sum((I - mean(I)).^2);
R2_V = 1 - sum((V - V_hat).^2) / sum((V - mean(V)).^2);
R2_R = 1 - sum((R - R_hat).^2) / sum((R - mean(R)).^2);

fprintf('\n=== Error metrics (fractional q = %.2f) ===\n', q);
fprintf('MSE:  S=%.3e, I=%.3e, V=%.3e, R=%.3e\n', MSE_S, MSE_I, MSE_V, MSE_R);
fprintf('RMSE: S=%.3e, I=%.3e, V=%.3e, R=%.3e\n', RMSE_S, RMSE_I, RMSE_V, RMSE_R);
fprintf('R^2:  S=%.6f, I=%.6f, V=%.6f, R=%.6f\n', R2_S, R2_I, R2_V, R2_R);

%% ================== Plots: reference vs DNN ==================
figure;
subplot(2,2,1);
plot(t, S, 'k-', 'LineWidth', 1.5); hold on;
plot(t, S_hat, 'r--', 'LineWidth', 1.5);
xlabel('t'); ylabel('S(t)');
legend('Fractional solver','DNN','Location','best');
title('S(t)');

subplot(2,2,2);
plot(t, I, 'k-', 'LineWidth', 1.5); hold on;
plot(t, I_hat, 'r--', 'LineWidth', 1.5);
xlabel('t'); ylabel('I(t)');
legend('Fractional solver','DNN','Location','best');
title('I(t)');

subplot(2,2,3);
plot(t, V, 'k-', 'LineWidth', 1.5); hold on;
plot(t, V_hat, 'r--', 'LineWidth', 1.5);
xlabel('t'); ylabel('V(t)');
legend('Fractional solver','DNN','Location','best');
title('V(t)');

subplot(2,2,4);
plot(t, R, 'k-', 'LineWidth', 1.5); hold on;
plot(t, R_hat, 'r--', 'LineWidth', 1.5);
xlabel('t'); ylabel('R(t)');
legend('Fractional solver','DNN','Location','best');
title('R(t)');

sgtitle('Fractional SIVR: solver vs DNN');

%% ================== Plot absolute errors ==================
figure;
plot(t, AE_S, 'LineWidth', 1.5); hold on;
plot(t, AE_I, 'LineWidth', 1.5);
plot(t, AE_V, 'LineWidth', 1.5);
plot(t, AE_R, 'LineWidth', 1.5);
xlabel('t');
ylabel('Absolute error');
legend('|S - Shat|','|I - Ihat|','|V - Vhat|','|R - Rhat|','Location','best');
title('Pointwise absolute errors (DNN vs fractional solver)');
grid on;
