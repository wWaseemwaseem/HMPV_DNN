function OptimalControl(xout)
clc
set(0,'DefaultAxesFontSize',12)
T = 50;     % Total time
h = 0.5;    % Time step
num = T/h;  % Number of time steps
del = 0.001; 
t = linspace(0,T,num+1); % Time vector

    % Maximum control values
maxu = [1.00 1.00 1.00 1.00]; 
A1 = .20; A2 = .50; A3 = .20; A4 =5; A5=10; A6=5;
 % Model parameters (adjust as needed)
Delta = 0.1;   mu = 0.0004; beta = 0.35; tau1 = 0.6; tau2 = 0.4; tau3 = 0.2; kappa = 0.03; sigma = 1/5.1;r = 0.67; gamma1 = 1/7;
gamma2 = 0.01; gamma3 = 1/14;gamma4 = 1/21;phi = 0.02; delta1 = 0.01;delta2 = 0.0003;delta3 = 0.001;omega = 1/180;
    % Initial values for the state variables [S, E, A, I, H, C, R]
    xin(:,1) =[10000; 100; 15; 20; 10; 5; 0]; 
    % Runge-Kutta solver to integrate the model
    xout = Runge_Kutta(xin, num, 0.1); 
    xout(:,num+1);
   
    tu = zeros(3, num+1);
    x = zeros(7, num+1);
    La = zeros(num+1, 7);
    
    x(:,1) = xin(:,1);  

    % Initial control values (zero)
test= -5; 
i=0;   %num+1
k=0;
disp('start of control')
tu(1,1) =   0;   0.7; 0.50;  1; 
tu(2,1) =   0;   0.7; 0.50;  1; 
tu(3,1) =   0;   0.7; 0.50;  1;
% tu = zeros(4, num+1);
% tu(:,1) = [0; 0.7; 0.5; 1];
vec= [tu ; x ; La'];

     while( test<10^(-8))  %   && k<num+1  
        
%                        oldvec = vec;  vec=[tu;tx;tl'];
         [tu,tx,tl]=forward_backward(x,La,tu,num,h);  
        
        % Extracting state variables from the integrated solution
        S = tx(1,:); E = tx(2,:); A = tx(3,:); I = tx(4,:); H = tx(5,:); C = tx(6,:);
        R = tx(7,:);
        La1 = tl(:,1); La2 = tl(:,2); La3 = tl(:,3); La4 = tl(:,4); La5 = tl(:,5); La6 = tl(:,6);
        La7 = tl(:,7);

        % old control values
        u1 = tu(1,:);   u2 = tu(2,:);  u3 = tu(3,:);
         oldu1 = u1;   oldu2 = u2;  oldu3 = u3;
         oldtu=tu; oldtx=tx; oldtl=tl;

        % Update control variables
        N =S+E+A+I+H+C+R;  
       tempu1 = (beta.* S .*(A+tau1.*I + tau2.*H + tau3.*C)).*(La2' - La1') ./ (A4.*N);
       
 u11 = min(maxu(1),max(tempu1,0)); %   
  u1 = 0.5*(u11 + oldu1);  %  2; 
              % u1=0;
           
tempu2 = I.*(La4'-La5')./A5;

       u21 = min(maxu(1),max(tempu2,0)); %   
       u2 = 0.5*(u21 + oldu2); 
                      % u2=0;

tempu3 = ((La4' -La7') .* I) / A6;


                      % tempu3 = (La3' - La4') * Ih  ./ A8 ;

                         u31 = min(maxu(1),max(tempu3,0)); %   
                         u3 = 0.5*(u31 + oldu3);
     %                       u3=0;
     %tempu4 =  (beta5 .* Ip .* Sp .* (La8' - La7')) ./ (A9 .* Np);
     % tempu4 = (La8' - La7') .* (beta5 * Ip .* Sp) ./ (A9 * Np);
%  u41 = min(maxu(1),max(tempu4,0)); %   
%                          u4 = 0.5*(u41 + oldu4);             
   %              u4=0;    
   
tu(1,:) = u1;  tu(2,:) = u2;  tu(3,:) = u3;
                  
                  k = k+1; 
                  
               
% Update control vector
      %  tu(:,1) = [0; 0.7; 0.5; 1];

      %  k = k + 1;
        % Test for convergence
 test=min([del*sum(tu,1)-sum(oldtu-tu,1) del*sum(tx,1)-sum(oldtx-tx,1) del*sum(tl,1)-sum(oldtl-tl,1)]);
        % Check if we have reached convergence
        if k > 1
            break
        end
        
     end
printout(t,tx,tu,xout,num); 
    
return

function printout(t,x,uu,xout,num) 
save alldataHMPV
%subplot(3, 3, 1);
figure(1) 
plot(t,xout(1,:),'r',t,x(1,:),'b--','linewidth', 2); %
title('(a)');
xlabel('t(time)');
ylabel('S(t) ');axis tight
legend('Without control', 'u_1 \neq 0, u_2 \neq 0, u_3 \neq 0' )
grid on  


%subplot(3, 3, 2);
figure(2)
plot(t,xout(2,:),'r',t,x(2,:),'b--','linewidth', 2); %
title('(b)');
xlabel('t(time)');
ylabel('E(t) ');axis tight
legend('Without control', 'u_1 \neq 0, u_2 \neq 0, u_3 \neq 0' )
grid on
%subplot(3, 3, 3);
figure(3)
plot(t,xout(3,:),'r',t,x(3,:),'b--','linewidth', 2);
xlabel('t(time)');
ylabel('A(t)');  axis tight
title('(c)');
legend('Without control','u_1 \neq 0, u_2 \neq 0, u_3 \neq 0' )
grid on
%subplot(3, 3, 4);
figure(4)
plot(t,xout(4,:),'r',t,x(4,:),'b--','linewidth', 2);
xlabel('t(time)');
title('(d)');
ylabel('I(t)');  axis tight
legend('Without control', 'u_1 \neq 0, u_2 \neq 0, u_3 \neq 0' )
grid on
%subplot(3, 3, 5);
figure(5)
plot(t,xout(5,:),'r',t,x(5,:),'b--','linewidth', 2);
xlabel('t(time)');
ylabel('H(t)');  axis tight
title('(e)');
legend('Without control', 'u_1 \neq 0, u_2 \neq 0, u_3 \neq 0' )
grid on
%subplot(3, 3, 6);
figure(6)
plot(t,xout(6,:),'r',t,x(6,:),'b--','linewidth', 2);
xlabel('t(time)');
ylabel('C(t)');  axis tight
title('(f)');
legend('Without control', 'u_1 \neq 0, u_2 \neq 0, u_3 \neq 0' )
grid on
%subplot(3, 3, 7);
figure(7)
plot(t,xout(7,:),'r',t,x(7,:),'b--','linewidth', 2);
xlabel('t(time)');
ylabel('R(t)');  axis tight
title('(g)');
legend('Without control', 'u_1 \neq 0, u_2 \neq 0, u_3 \neq 0' )
grid on
% %subplot(3, 3, 8);
% figure(8)
% plot(t,xout(8,:),'r',t,x(8,:),'b--','linewidth', 2);
% xlabel('t(time)');
% ylabel('I_p(t)');  axis tight
% title('(h)');
% legend('Without control', 'u_1 \neq 0, u_2 \neq 0, u_3 \neq 0, u_4 \neq 0' )
% grid on   
% %subplot(3, 3, 9);
% figure(9)
% plot(t,xout(9,:),'r',t,x(9,:),'b--','linewidth', 2);
% xlabel('t(time)');
% ylabel('R(t)');  axis tight
% title('(h)');
% legend('Without control', 'u_1 \neq 0, u_2 \neq 0, u_3 \neq 0' )
% grid on

%subplot(3, 3, 10);
figure(10)
plot(t,uu(1,1:num+1),'g',t,uu(2,1:num+1),'r',t,uu(3,1:num+1),'b','LineWidth',3)%
xlabel('t(time)');
title('(i)');
ylabel('Control Profile'); axis tight
legend('u_1 \neq 0', 'u_2 \neq 0', 'u_3 \neq 0')
grid on   



return

end

function x=Runge_Kutta(x,num,h)
    %4th order Runge-Kutta
    for i = 1:num
        tempu=[0,0,0,0];
        tempx=x(:,i);
        [k1v, k2v, k3v, k4v, k5v, k6v, k7v]=forwards(tempx,tempu);        
        k1=[k1v; k2v; k3v; k4v; k5v; k6v; k7v];
        tempx=x(:,i)+k1*0.5*h; 
        [k1v, k2v, k3v, k4v, k5v, k6v, k7v]=forwards(tempx,tempu);
        k2=[k1v; k2v; k3v; k4v; k5v; k6v; k7v];
        tempx=x(:,i)+k2*0.5*h;
       [k1v, k2v, k3v, k4v, k5v, k6v, k7v]=forwards(tempx,tempu);
        k3=[k1v; k2v; k3v; k4v; k5v; k6v; k7v];
        tempx=x(:,i)+k3*h;
        [k1v, k2v, k3v, k4v,  k5v, k6v, k7v]=forwards(tempx,tempu);
        k4=[k1v; k2v; k3v; k4v; k5v; k6v; k7v];

         x(:,i+1)=max(x(:,i)+h/6*(k1+2*k2+2*k3+k4),0);
    end
end
        % display('inside forward')   u pause
function [u,x,La]=forward_backward(x,La,u,num,h) 
 
    %4th order Runge-Kutta
    for i=1:num
        tempu=(u(:,i)+u(:,i+1))/2;
        tempx=x(:,i);
                [k1v, k2v, k3v, k4v, k5v, k6v, k7v]=forwards(tempx,tempu);        
        k1=[k1v; k2v; k3v; k4v; k5v; k6v; k7v];
        tempx=x(:,i)+k1*0.5*h; 
        [k1v, k2v, k3v, k4v, k5v, k6v, k7v]=forwards(tempx,tempu);
        k2=[k1v; k2v; k3v; k4v; k5v; k6v; k7v];
        tempx=x(:,i)+k2*0.5*h;
       [k1v, k2v, k3v, k4v, k5v, k6v, k7v]=forwards(tempx,tempu);
        k3=[k1v; k2v; k3v; k4v; k5v; k6v; k7v];
        tempx=x(:,i)+k3*h;
        [k1v, k2v, k3v, k4v,  k5v, k6v, k7v]=forwards(tempx,tempu);
        k4=[k1v; k2v; k3v; k4v; k5v; k6v; k7v];

         x(:,i+1)=max(x(:,i)+h/6*(k1+2*k2+2*k3+k4),0);
    end

    
    for i=num:-1:1
        tempx=(x(:,i)+x(:,i+1))/2;
        tempu=(u(:,i)+u(:,i+1))/2;        
       
        tLa=La(i+1,:);
        
        [k1v, k2v, k3v, k4v, k5v, k6v, k7v]=backwards(tempx, tLa, tempu);    
        k1=[k1v k2v k3v k4v k5v k6v k7v];
        tLa=La(i+1,:)-k1*0.5*h;
        [k1v, k2v, k3v, k4v, k5v, k6v, k7v]=backwards(tempx, tLa, tempu);
        k2=[k1v k2v k3v k4v k5v k6v k7v];
        tLa=La(i+1,:)-k2*0.5*h;
        [k1v, k2v, k3v, k4v, k5v, k6v, k7v]=backwards(tempx, tLa, tempu); 
        k3=[k1v k2v k3v k4v k5v k6v k7v];
        tLa=La(i+1,:)-k3*h;
        [k1v, k2v, k3v, k4v, k5v, k6v, k7v]=backwards(tempx, tLa, tempu);   
        k4=[k1v k2v k3v k4v k5v k6v k7v ];
        
   
        La(i,:)=La(i+1,:)-(h/6)*(k1+2*k2+2*k3+k4);
    end

     
                 
    return
end

function [f1,f2,f3,f4,f5, f6,f7]=backwards(tx,tl,tu)   
        
         S = tx(1,:); E = tx(2,:); A = tx(3,:); I = tx(4,:); H = tx(5,:); C = tx(6,:); R = tx(7,:);  
        La1 = tl(:,1); La2 = tl(:,2); La3 = tl(:,3); La4 = tl(:,4); La5 = tl(:,5); La6 = tl(:,6);
        La7 = tl(:,7);  
          u1 = tu(1);   u2 = tu(2); u3 = tu(3);
        
    N=S+E+A+I+H+C+R;       
 % Adjoint equations (co-state derivatives)
% Adjoint (lambda) equations in MATLAB

f1 = ((1-u1)*beta*(A +tau1*I +tau2*H +tau3*C )*(N-S )/(N*N))*(La1 - La2) + mu*La1;
f2 = (((1-u1)*beta*S*(A +tau1*I +tau2*H +tau3*C ))/(N*N))*(La2 - La1)+(sigma+mu)*La2-sigma*((1-r)*La3+r*La4);
f3 = (((1-u1)*beta*S *(N-(A +tau1*I +tau2*H +tau3*C)))/(N*N))*(La1 - La2)+(gamma1+mu)*La3-gamma1*La7;
f4 =-A1+(((1-u1)*beta*S *(tau1*N-(A +tau1*I +tau2*H +tau3*C )))/(N*N))*(La1 - La2) +(u2+phi)*(La4-La5) + (u3+gamma2 )*(La4-La7) + ( mu + delta1)*La4-delta1*La6;
f5 =-A2+(((1-u1)*beta*S *(N*tau2-(A +tau1*I +tau2*H +tau3*C )))/(N*N))*(La1 - La2) -delta2*(La6-La5) - gamma3*(La7-La5) + mu*La5;
f6 = (((1-u1)*beta*S *(N*tau3-(A +tau1*I +tau2*H +tau3*C )))/(N*N))*(La1 - La2) + gamma4*(La6-La7) + (mu + delta3)*La6; 
f7 = -A3+(((1-u1)*beta*S*(A +tau1*I +tau2*H +tau3*C ) )/(N*N))*(La2 - La1) + omega*(La7-La1)+ mu*La7;  
            return
    end
    
function [f1,f2,f3,f4,f5,f6,f7]=forwards(tx,tu) 
       S = tx(1,:); E = tx(2,:); A = tx(3,:); I = tx(4,:); H = tx(5,:); C = tx(6,:); R = tx(7,:);  
          u1 = tu(1);   u2 = tu(2); u3 = tu(3);
  

  %Model   
  % State equations (f1 to f7)
f1 = Delta - (((1-u1)*beta*S*(A +tau1*I +tau2*H +tau3*C))./(S+E+A+I+H+C+R))  - mu*S  + omega*R ;
f2 = (((1-u1)*beta*S*(A +tau1*I +tau2*H +tau3*C ))./(S+E+A+I+H+C+R))  - (sigma + mu)*E ;
f3 = (1-r)*sigma*E  - (gamma1 + mu)*A ;
f4 = r*sigma*E  - (u2 + phi + mu + delta1)*I  - (gamma2+u3)*I ;
f5 = (phi+u2)*I  - (gamma3 + mu + delta2)*H ;
f6 = delta1*I  + delta2*H  - (gamma4 + mu + delta3)*C ;
f7 = u3*I + gamma1*A  + gamma2*I  + gamma3*H  + gamma4*C  - (mu + omega)*R ;
    return
end


end
