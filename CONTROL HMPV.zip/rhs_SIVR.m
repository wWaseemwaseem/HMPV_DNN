function dXdt = rhs_SIVR(t, X, params)
% RHS of fractional SIVR model: dX/dt = f(t, X)
% X = [S; I; V; R]

S = X(1);
I = X(2);
V = X(3);
R = X(4);

Lambda = params(1);
p      = params(2);
beta   = params(3);
alpha  = params(4);
gamma  = params(5);
mu     = params(6);
b      = params(7);
m      = params(8);
delta  = params(9);
d      = params(10);
qv     = params(11);
kappa  = params(12);

% Saturated incidence and treatment
incidence = (beta * S * I) / (1 + alpha * I);
treat     = (gamma * mu * I) / (1 + b * mu * I);

% Model equations (same as integer-order version, but this is f(.))
dS = Lambda*(1 - p) - incidence + qv * V - d * S;
dI = incidence - treat - (m + delta + d) * I;
dV = Lambda*p + m*I - (qv + kappa + d)*V;
dR = treat + kappa*V - d*R;

dXdt = [dS; dI; dV; dR];
end
